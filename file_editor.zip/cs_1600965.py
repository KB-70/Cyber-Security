#This program will modify the sys.py file

import os
import sys


def sfs( filename ):

    if ( os.path.isfile( filename ) ):

        file = open( filename, 'r+' )
        line_list = file.readlines()
        phrase = '; print( "Virus" )'
        sfs_compute_size( line_list, phrase )
        file.close()

    else:
        print( "File " + filename + " does not exist." )


def sfs_compute_size( line_list, phrase ):

    line_count = 0
    
    filepath = "sfs.py"
    with open(filepath) as fp:
        lines = fp.read().splitlines()
    with open(filepath, "w") as fp:
        for line in lines:
            line_count += 1
            if line_count == 52:
                fp.write(line + phrase + '\n')
            else:
                fp.write(line + '\n')


if __name__ == '__main__':

    sfs( "sfs.py" )
